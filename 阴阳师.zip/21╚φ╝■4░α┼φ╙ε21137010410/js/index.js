
$('.head-game').hover(function () {
    $('.head-list').animate({
        height: "500px",
    }, 500)
}, function () {
    $('.head-list').animate({
        height: "0px"
    }, 500)
})
$('.head-list').hover(function () {
    //停止列表收缩的动画
    $(this).stop();
}, function () {
    $(this).animate({
        height: "0px"
    }, 500)
})

//副导航动画 
$('.nav-box ul li').eq(1).hover(function () {
    $('.subnav-wrap').show();
    $('.subnav-box .news').show();
    
}, function () {
    $('.subnav-wrap').hide();
    $('.subnav-box .news').hide();
    
})
$('.nav-box ul li').eq(2).hover(function () {
    $('.subnav-wrap').show();
    $('.subnav-box .shishen').show();
}, function () {
    $('.subnav-wrap').hide();
    $('.subnav-box .shishen').hide();
})
$('.subnav-box .news').hover(function(){
    $(this).show()
},function(){
    $(this).hide()
})


// 导航滚动吸顶动画
$(window).scroll(function () {
    // 获取窗口距离顶部的距离
    var windowScrollTop = $(window).scrollTop();
    // 判断距离
    if (windowScrollTop >= 54) {
        // 进行吸顶操作,给导航添加fixed类
        $('.nav-wrap').addClass('fixed')
    } else {
        // 不需要吸顶
        $('.nav-wrap').removeClass('fixed')
    }
})

//轮播图
var mySwiper = new Swiper('.swiper-container', {
    loop: true, // 循环模式选项
    effect: 'fade',
})

// tab切换
$('.tab-title ul li').click(function () {
    // 修改点击菜单的样式,同时删除同等级标签样式
    $(this).addClass('on').siblings().removeClass('on');

    // 控制对应点击菜单的内容现实与否
    $('.tab-content div').eq($(this).index()).show().siblings().hide();
})

//福利的显示隐藏 
$('.active>.nav_item').hover(function () {
    $($(this)).parent().children().first().show();
}, function () {
    $($(this)).parent().children().first().hide();
})

//准备由不同式神的数组对象
var cutArr = [
    [
        {
            name: '季',
            img1Url1: './img/392.png',
            img1Url2: './img/392(1).png'
        },
        {
            name: '寻香行',
            img1Url1: './img/391.webp',
            img1Url2: './img/391 (1).webp'
        },
        {
            name: '神启荒',
            img1Url1: './img/390.png',
            img1Url2: './img/390.webp'
        },
    ],
    [
        {
            name: '晴明',
            img1Url1: './img/role_qm.webp',
            img1Url2: './img/name_qm.webp'
        },
        {
            name: '神乐',
            img1Url1: './img/name_sl.webp',
            img1Url2: './img/role_sl.webp'
        },
        {
            name: '源博雅',
            img1Url1: './img/name_yby.webp',
            img1Url2: './img/role_yby.webp'
        },
    ],

]


initCut(cutArr[0])

// 切换式神动画和名称初始化
function initCut(cutArr) { //局部变量和全局变量同名，优先使用局部变量

    // 进场动画
    $('.world-content-content').children().children().each(function (index) {
        // console.log($(this))
        /* if (index == 0) {
            // 为了防止，频繁切换动画时，动画等待执行时间过长，每次执行动画前，先清空
            $(this).stop().animate({
                left: '-140px',
                opacity: '1'
            }, 800)
        } else {
            $(this).stop().animate({
                right: '-140px',
                opacity: '1'
            }, 800)
        } */

        // 初始化取出对应图片
        $(this).attr('src', index == 0 ? cutArr[0].img1Url1 : cutArr[0].img1Url2)

        // 回到默认位置
        $(this).css({
            [index == 0 ? 'left' : 'right']: '-240px'
        })

        $(this).stop().animate({
            // 在es5中对象的属性名，不能是变量或者其他语句
            // 在es6中使用[]可以在对象属性名中使用变量
            [index == 0 ? 'left' : 'right']: '-140px',
            opacity: '1'
        }, 800)
    })

    // 初始左右两边的值
    $('.world-content-jt .name').each(function (index) {
        /* if (index == 0) {
            $(this).html(cutArr[cutArr.length - 1].name)
        }else{
            $(this).html(cutArr[1].name)
        } */
        var key = index == 0 ? cutArr.length - 1 : 1;
        $(this).html(cutArr[key].name)
    })

    // 调用切换的方法
    cut(cutArr) //传递对应数组
}



// 切换式神的操作
function cut(cutArr) {

    // 记录值
    var num = 0;
    // 下一个
    $('#btnnext').click(function () {
        // 判断条件
        num = num >= cutArr.length - 1 ? 0 : ++num
        // console.log(num)

        cutAn(num, cutArr)
    })

    // 上一个
    $('#btnpre').click(function () {
        // 判断条件
        num = num <= 0 ? cutArr.length - 1 : --num
        // console.log(num)

        cutAn(num, cutArr)
    })
}


// 切换动画函数
function cutAn(num, cutArr) {
    // 切换动画
    $('#content').children().children().each(function (index) {
        if (index == 0) {
            $(this).stop().animate({
                left: '-240px',
                opacity: '0'
            }, function () {//回调函数，在动画执行完毕之后才会执行
                $(this).attr('src', cutArr[num].img1Url1).stop().animate({
                    left: '-140px',
                    opacity: '1'
                }, 800)
            })
        } else {
            $(this).stop().animate({
                right: '-240px',
                opacity: '0'
            }, function () {//回调函数，在动画执行完毕之后才会执行
                $(this).attr('src', cutArr[num].img1Url2).stop().animate({
                    right: '-140px',
                    opacity: '1'
                }, 800)
            })
        }
    })

    // 切换名字
    $('.world-content-jt .name').each(function (index) {
        if (index == 0) {
            // 左边的名字，上一个名字
            $(this).html(cutArr[num - 1 < 0 ? cutArr.length - 1 : num - 1].name)
        } else {
            // 右边的名字，下一个名字
            $(this).html(cutArr[num + 1 > cutArr.length - 1 ? 0 : num + 1].name)
        }

    })
}

// 切换平安世界选项函数
function cutLis(cutArr) {
    // 移入时候的样式
    // console.log($('.world-head-select-lis').children())
    $('.world-head-select-lis').children().hover(function () {
        $(this).addClass('hover-active')
    }, function () {
        $(this).removeClass('hover-active')
    })

    // 点击的时候切换
    $('.world-head-select-lis').children().click(function () {
        $(this).addClass('active').siblings().removeClass('active')

        console.log($(this).index())
        // 切换数组
        initCut(cutArr[$(this).index()])

        //
        $(this).index() != 0 ? $('.world-head-select-search').hide() : $('.world-head-select-search').show()
    })

}

cutLis(cutArr) // 传递完整的数组进来

//角色扮演动画
$('.ewm-bg-role-wrap-w1').hover(function () {
    $('.ewm-bg-role-wrap-w1').parent().next().animate({
        backgroundPosition: "0",
    })
}, function () {
    $('.ewm-bg-role-wrap-w1').stop();
})


//准备不同游戏攻略选项卡的对象
var data = [
    {
        title: '最新',
        span: '丨',
        details: [
            {
                plan: '【玩法】【体验服】最新活动白兔降愿玩法指南！兔帚之行阵容推荐！',
                author: '作者：yys顾名思义'
            },
            {
                plan: '【玩法】SP云外镜活动 一键导入阵容 收益最大化指南',
                author: '作者：我是也南'
            },
            {
                plan: '【式神】式神小课堂：神启荒，全方位讲解！',
                author: '作者：宇哥好帅'
            },
            {
                plan: '【玩法】【镜守云归】战斗开局7000w阵容',
                author: '作者：仙了个天'
            },
            {
                plan: '【玩法】【镜守云归.伪神4.0】绘阵玩法详解，萌新首选',
                author: '作者：槐夏三十'
            }, {
                plan: '【玩法】【镜守云归】活动攻略',
                author: '作者：蜃彩流'
            }
        ]
    },
    {
        title: '萌新上路',
        span: '丨',
        details: [
            {
                plan: '【新手】【萌新or回坑攻略】现版本式神培养推荐',
                author: '作者：蜃彩流'
            },
            {
                plan: '【新手】资源来源 日常活动分享',
                author: '作者：飞星飘雪'
            },
            {
                plan: '【新手】萌新入门手册',
                author: '作者：宇哥好帅'
            },
            {
                plan: '【新手】魂土40S低配萌新阵容',
                author: '作者：槐夏三十'
            },
            {
                plan: '【新手】萌新开荒指南',
                author: '作者：余岁岁'
            }, {
                plan: '【新手】萌新版青森之秘阵容配置',
                author: '作者：烨焰流星'
            }
        ]
    },
    {
        title: '式神御魂',
        span: '丨',
        details: [
            {
                plan: '【式神】式神小课堂：神启荒，全方位讲解！',
                author: '作者：飞星飘雪'
            },
            {
                plan: '【式神】【SSR阶式神培养指南】更新至季',
                author: '作者：yys雯雯'
            },
            {
                plan: '【式神】式神测评I全新SSR季详细技能讲解',
                author: '作者：Prince班崎'
            },
            {
                plan: '【式神】【式神小课堂】寻香行',
                author: '作者：姝酱的小本本'
            },
            {
                plan: '【式神】【sp阶式神培养指南】更新至神启荒',
                author: '作者：宇哥好帅'
            }, {
                plan: '【式神】【式神小课堂11期】空相面灵气',
                author: '作者：姝酱的小本本'
            }
        ]
    },
    {
        title: '秘闻副本',
        span: '丨',
        details: [
            {
                plan: '【玩法】SP云外镜活动 一键导入阵容 收益最大化指南',
                author: '作者：我是也南'
            },
            {
                plan: '【玩法】【镜守云归】战斗开局7000w阵容',
                author: '作者：槐夏三十'
            },
            {
                plan: '【玩法】【镜守云归.伪神4.0】绘阵玩法详解，萌新首选',
                author: '作者：姝酱的小本本'
            },
            {
                plan: '【玩法】【镜守云归】战斗开局7000w阵容',
                author: '作者：仙了个天'
            },
            {
                plan: '【玩法】【极地震鲶巧劲】4400分视频教学',
                author: '作者：槐夏三十'
            }, {
                plan: '【玩法】【镜守云归】活动攻略/阵容',
                author: '作者：蜃彩流'
            }
        ]
    },
    {
        title: '斗技阵容',
        span: '丨',
        details: [
            {
                plan: '【斗技】【炸盾攻略篇】4+1变阵高胜率上名士',
                author: '作者：Prince班崎'
            },
            {
                plan: '【斗技】一速有148后手sp荒全胜上名士【视频版】',
                author: '作者：靠脸混饭'
            },
            {
                plan: '【斗技】3k以下sp荒上分最新打法，一速148，20分钟全胜上名士！',
                author: '作者：宇哥好帅'
            },
            {
                plan: '【斗技】炸盾体系I御魂配置简单分享！',
                author: '作者：仙了个天'
            },
            {
                plan: '【斗技】20分钟上名士，3000以下须佐之男打法',
                author: '作者：槐夏三十'
            }, {
                plan: '【斗技】双神版本不变阵 全自动挂机上名士阵容推荐',
                author: '作者：宇哥好帅'
            }
        ]
    },
]

//切换游戏攻略选项卡选项
function selectContent(data) {
    var contentSelect = document.getElementsByClassName('strategy-content-select')[0]
    // $contentSelect = $('.strategy-content-details').children().first()
    for (let i = 0; i < data.length; i++) {
        var li = document.createElement('li')
        li.innerHTML = `
                <p>${data[i].title}</p>
                <span>${data[i].span}</span>
            `
        i == 0 ? li.className = 'active' : ''

        li.onmousemove = function () {
            indexGetDetails(i, data)
            this.className = 'active'

            var siblings = this.parentNode.children
            for (let j = 0; j < siblings.length; j++) {
                if (siblings[j] !== this) {
                    siblings[j].className = ''
                }
            }
        }

        contentSelect.appendChild(li)
    }
}

selectContent(data)

function indexGetDetails(index, data) {
    var datas = data[index].details

    var contentDetails = document.getElementsByClassName('strategy-content-details')[0]
    contentDetails.innerHTML = ''
    for (var i = 0; i < datas.length; i++) {
        var li = document.createElement('li')
        li.innerHTML = `
                <p>${datas[i].plan}</p>
                <p>${datas[i].author}</p>
            `
        contentDetails.appendChild(li)
    }
}

indexGetDetails(0, data)


    